# PythonCheckers
In order to learn Python, I developed a simple GUI based Checkers game. Implemented using Tk GUI library, it was a great project that allowed me to explore the language and create something fun at the same time. 

Getting Started
1. Clone the respository.

    `$ git clone https://github.com/steerzac/PythonCheckers.git`

2. Check that python is installed

    `$ python --version`

3. If python is installed, run the app

    `$ python __init__.py`

4. If python is not installed, install python and run the app.

    `$ brew install python`

    `$ python __init__.py`

5. Enjoy your game of checkers!
