import tkinter
from tkinter import *
from checkerBoard import CheckerBoard
    
def main():
    newCheckerBoard = CheckerBoard()
    
main()